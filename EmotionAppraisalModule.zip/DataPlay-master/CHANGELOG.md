v1.1.1:   API metric probes are now on each master nodes.

v1.1.0:   Support for PostgreSQL cluster using pgpool-II

v1.0.2:   Added API health monitoring probes.

v1.0.1:   System-wide environment variables

v1.0.0:   CELAR compatible scripts

v0.9.1:   Deployment Scripts

v0.9.0:   Update to AngularJS v1.3

v0.8.9:   Use NVD3 for Correlated Charts

v0.8.5:   Added Correlated Charts

v0.8.0:   Added Related Charts

v0.7.5:   Added DC.js for Charts

v0.7.2:   Use Bootstrap for HTML

v0.7.0:   Migrated frontend to AngularJS

v0.6.1:   Moved Sessions to Redis

v0.6.0:   Use GORM for PostgreSQL

v0.5.0:   Go 1.1 with embedded HTML views
